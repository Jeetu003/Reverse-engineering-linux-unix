#ifndef ASM_P_ASM_SNES_H
#define ASM_P_ASM_SNES_H

struct snes_asm_flags {
	unsigned char M; 
	unsigned char X;
};

#endif
