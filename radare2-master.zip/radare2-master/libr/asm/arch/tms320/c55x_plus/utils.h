#ifndef UUTILS_H
#define UUTILS_H

#include <r_types.h>
#define C55PLUS_DEBUG 0

char *strcat_dup(char *s1, char *s2, st32 n_free);
char *get_hex_str(ut32 hex_num);

#endif
